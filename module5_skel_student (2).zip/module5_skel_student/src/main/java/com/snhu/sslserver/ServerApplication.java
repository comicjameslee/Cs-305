package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;



@SpringBootApplication
public class ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerApplication.class, args);
	}

}

@RestController
class ServerController{
//FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Hello Ezra Carter !";
    	try {
    		// setting up SHA-256
    	      MessageDigest md = MessageDigest.getInstance("SHA-256");
    	      
    	      // apply the cipher to the program
    	      md.update(data.getBytes());
    	      byte[] digest = md.digest();      
    	      
    	      // converting to hexadecimal
    	      StringBuffer hexa = new StringBuffer();
    	      for(byte Byte: digest ) {
    	    	  hexa.append(Integer.toHexString(0xFF & Byte));
    	      }
    	      return "<p>data: "+data + "or SHA-256" + digest + " or in hex string \n " + hexa;
    	}catch (Exception e) {
    		System.out.print("I didn't work");
    	}
       
        return "<p>data:"+data;
    }
}
