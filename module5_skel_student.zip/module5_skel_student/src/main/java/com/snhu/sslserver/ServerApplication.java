package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;



@SpringBootApplication
public class ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerApplication.class, args);
	}

}

@RestController
class ServerController{
//FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Hello Ezra Carter !";
    	try {
    	      MessageDigest md = MessageDigest.getInstance("SHA-256");
    	      md.update(data.getBytes());
    	      byte[] digest = md.digest();      
    	      System.out.println(digest);  
    	      StringBuffer hexstring = new StringBuffer();
    	      for(int i= 0; i < digest.length; i++) {
    	    	  hexstring.append(Integer.toHexString(0xFF & digest[i]));
    	      }
    	      return "<p>data: "+data + "or SHA-256" + digest + " or in hex string \n" + hexstring;
    	}catch (Exception e) {
    		System.out.print("I didn't work");
    	}
       
        return "<p>data:"+data;
    }
}
