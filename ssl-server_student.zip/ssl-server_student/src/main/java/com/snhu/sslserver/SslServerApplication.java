package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
}

@RestController
class ServerController {

	@RequestMapping("/checksum")
	public String myHash() {
		String data = "Hello Ezra Carter !";
		String cipherName = "SHA-256";
		
		try {
			// Initialize MessageDigest with the selected cipher
			MessageDigest md = MessageDigest.getInstance(cipherName);
			
			// Generate the byte array digest
			byte[] digest = md.digest(data.getBytes(StandardCharsets.UTF_8));      
			
			// Convert the hash value to a proper hexadecimal string
			StringBuilder hexa = new StringBuilder();
			for (byte b : digest) {
				hexa.append(String.format("%02x", b));
			}
			
			// Construct structured output for the web browser view
			return  "<p><b>Data String:</b> " + data + "</p>" +
			       "<p><b>Checksum Hash Value:</b> " + hexa.toString() + "</p>";
			       
		} catch (Exception e) {
			return "<p>Error generating checksum visualization.</p>";
		}
	}
}